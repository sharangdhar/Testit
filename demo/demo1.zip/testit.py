from demo1 import isPrime
